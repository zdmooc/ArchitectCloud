
from with1 import timing
import time

with timing():
    time.sleep(5)
