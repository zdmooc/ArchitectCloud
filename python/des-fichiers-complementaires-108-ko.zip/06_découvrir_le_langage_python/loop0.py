# fichier loop0.py

# Boucle while
compteur = 1

while compteur <= 10:
    print("Compteur : %s " % compteur)
    compteur += 1


# Boucle for
for n in [1,2,3]:
	print(n)
