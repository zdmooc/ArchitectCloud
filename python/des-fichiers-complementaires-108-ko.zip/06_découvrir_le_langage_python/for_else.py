
for x in range(1,5):
    print("boucle for : ", x)
else:
    print(" Fin de boucle : ", x)
