##
## Bienvenue
##

def hello():
    return "Bienvenue dans notre restaurant"

def test():
    print( hello() )

if __name__ == '__main__':
    test()
