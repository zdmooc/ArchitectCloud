##
## Paquet 2 Module 2
##

M2_VAR = 20

def M2_f2():
    print("__name__ = ", __name__)
    print("Paquet 2 : Module 2 : f2")
