##
## Paquet 1 / Module 1
##

M1_VAR = 10

def M1_f1():
    print("__name__ = ", __name__)
    print("Paquet 1 : Module 1 : f1")
