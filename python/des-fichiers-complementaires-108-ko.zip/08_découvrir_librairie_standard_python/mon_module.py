
import logging

def ma_fonction():
    logging.info(" Coucou je suis dans mon module / ma fonction")
