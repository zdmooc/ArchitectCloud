import logging

logging.basicConfig(filename='test.log',level=logging.DEBUG)
logging.warning("1er Avertissement")
logging.debug("2eme Avertissement")
